﻿namespace WeltevreeCore6.Models.Tests
{
    public class verblijf
    {
    }
}