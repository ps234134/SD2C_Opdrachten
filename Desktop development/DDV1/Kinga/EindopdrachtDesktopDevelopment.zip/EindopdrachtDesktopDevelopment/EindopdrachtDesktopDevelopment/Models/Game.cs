﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindopdrachtDesktopDevelopment.Models
{
    public class Game
    {
            private int id;

            public int ID
            {
                get { return id; }
                set { id = value; }
            }

            private string gameName;

            public string GameName
            {
                get { return gameName; }
                set { gameName = value; }
            }
        }
    }

